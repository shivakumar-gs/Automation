package com.qa.opencart.pages;

public class CartPage {
	
	public void addToCart() {
		System.out.println("Add to cart");
	}

}
