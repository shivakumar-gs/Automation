package com.qa.opencart.utils;

public class Error {

	public static final String TIME_OUT_WEB_ELEMENT_MESG = "....Element is not found in the given time....";

	public static final String TIME_OUT_ALERT_MESG = "....ALERT is not found in the given time....";

	public static final String TIME_OUT_FRAME_MESG = "....FRAME is not found in the given time....";
}